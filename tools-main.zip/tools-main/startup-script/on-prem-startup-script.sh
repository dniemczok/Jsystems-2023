# for rhel based vm-s only
# https://acloudguru.com/blog/engineering/adding-a-jenkins-agent-node
yum install -y java-11-openjdk-devel git docker curl openssl wget tree
useradd -d /var/lib/jenkins jenkins
systemctl enable docker && systemctl start docker
groupadd docker
chown -R root:docker /var/run/docker.sock
systemctl restart docker
if [[ ! -e ~/.ssh/id_rsa ]]; then
  ssh-keygen -q -t rsa -N '' -f ~/.ssh/id_rsa <<<y
  mkdir -p /var/lib/jenkins/.ssh
  touch /var/lib/jenkins/temp_to_remove
  cp ~/.ssh/id_rsa.pub /var/lib/jenkins/.ssh/authorized_keys
fi
# Install maven
wget https://dlcdn.apache.org/maven/maven-3/3.8.6/binaries/apache-maven-3.8.6-bin.tar.gz
tar xzvf apache-maven-3.8.6-bin.tar.gz
ln -s /opt/apache-maven-3.8.6 /opt/maven

if [[ ! -e /etc/profile.d/maven.sh ]]; then
cat > /etc/profile.d/maven.sh <<EOF
# Apache Maven Environmental Variables
# MAVEN_HOME for Maven 1 - M2_HOME for Maven 2
export JAVA_HOME=/usr/lib/jvm/jre-11-openjdk

export M2_HOME=/opt/maven

export MAVEN_HOME=/opt/maven

export PATH=${M2_HOME}/bin:${PATH}
EOF
fi

chmod +x /etc/profile.d/maven.sh
ln -s /opt/apache-maven-3.8.6/bin/mvn /usr/local/sbin/mvn

## !!!! Use java 11 !!!