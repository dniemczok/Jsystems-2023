# Uruchamianie Jenkinsa z uzyciem Docker-Compose

1. Start Jenkins Master 
` docker-compose -f docker-compose-jenkins.yaml up -d `

2. Dodanie agent'a slave w UI Jenkins Master ( nazwa slave'a musi się zgadzac ze zmienna JENKINS_AGENT_NAME z docker-compose-jenkins-slave.yaml)

3. Po dodaniu agent'a i zapisaniu pojawi sie secret, ktory mozna uzyc w celu dodania slave'a

4. Skopiowanie secret'u do docker-compose-jenkins-slave pod zmienna srodowiskowa `JENKINS_SECRET`

5. Start Jenkins Slave
` docker-compose -f docker-compose-jenkins-slave.yaml up -d `


6. Listing installed plugins 
`JENKINS_HOST=username:password@myhost.com:port `

` curl -sSL "http://$JENKINS_HOST/pluginManager/api/xml?depth=1&xpath=/*/*/shortName|/*/*/version&wrapper=plugins" | perl -pe 's/.*?<shortName>([\w-]+).*?<version>([^<]+)()(<\/\w+>)+/\1 \2\n/g'|sed 's/ /:/' `