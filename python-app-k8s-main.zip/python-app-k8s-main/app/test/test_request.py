import flask
import json
from src.app import configure_routes


def test_request():
    app = flask.Flask(__name__)
    configure_routes(app)
    # Make request
    response = app.test_client().get(
        '/api/echo?text=foo'
    )
    # Get data from request
    data = json.loads(response.get_data(as_text=True))
    # Assertions
    assert response.status_code == 200
    assert data["text"] == "foo"