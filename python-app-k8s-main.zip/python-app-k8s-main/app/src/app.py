import flask
import os

def configure_routes(app):
  @app.route('/api/echo', methods=['GET'])
  def home():
      return flask.request.args

  @app.route('/-/health', methods=['GET'])
  def health():
      health_info = {
          "serverHostname": flask.request.host
      }
      return health_info

if __name__ == '__main__':
    #Initiate app
    app = flask.Flask(__name__)
    # Configure routes
    configure_routes(app)
    #Define variables with port and debug
    port = int(os.environ.get('PORT', 8080))
    debug_mode = os.environ.get('DEBUG_MODE', False)
    #Run Application
    app.run(debug=debug_mode, host='0.0.0.0', port=port)



