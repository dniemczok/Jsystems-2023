# Simple web application

## Description
To run this simple web server i used flask framework because it is lightweight and simple to run


# What have been done
1. Gitlab CI scripts that includes:
  * unit tests
  * building image
  * helm linter
  * helm deployment

** helm deployemnt prepared but it requires preapring gitlab agent for EKS cluster

2. Chart with deployemnt, service, secret, configmap and ingress 
(Values with reigstry secret should be put in secure way)

3. Every file conntected with application lays in app folder

4. Dockerfile in root folder

5. Test6
