// Declarative //
pipeline {
    agent none
	options {
		timestamps()
	}
    stages {
        stage('STAGE-A') {
            input {
              message 'Should we proceed ?'
              submitter 'mgul'
            }
            steps {
                echo "Test"
            }
        }
		stage ('STAGE-B') {
            parallel {
                stage('STAGE-C') {
                    agent any
                    steps {
                        echo "I'm in STAGE-C"
                        sleep 10
                    }
                }
                stage('STAGE-D') {
                    agent any
                    steps {
                        echo "I'm in STAGE-C"
                        sleep 10
                        sh 'exit 1'

                    }
                }
                stage ('STAGE-E') {
                    agent any
                    steps {
                        echo "I'm in STAGE-D"
                        sleep 10
                    }
                }
        }
    }
}
}
// Script //
