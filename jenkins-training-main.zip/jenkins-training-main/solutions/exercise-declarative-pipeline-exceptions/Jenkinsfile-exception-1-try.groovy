pipeline {
    agent any
    
    stages {
        stage("Pull image 1") {
            steps {
                script {
                    try {
                        def image = docker.image("python:3.6.12-alpine")
                        image.pull()
                    }
                    catch (Exception e) {
                        println "exception ${e}"
                        println "Problem with pull image"
                    }
                }
            }
        }
        stage("Pull image 2") {
            steps {
                script {
                    try {
                        def image = docker.image("python:not_existing_tag")
                        image.pull()
                    }
                    catch (Exception e) {
                        println "exception ${e}"
                        println "Problem with pull image"
                        currentBuild.result = 'UNSTABLE'
                    }
                }
            }
        }
    }
}