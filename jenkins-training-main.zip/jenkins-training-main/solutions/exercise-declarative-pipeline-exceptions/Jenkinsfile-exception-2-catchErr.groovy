pipeline {
    agent any
    
    stages {
        stage("Pull image 1") {
            steps {
                script {
                    catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE' ) {
                        def image = docker.image("python:3.6.12-alpine")
                        image.pull()
                    }
                }
            }
        }
        stage("Pull image 2") {
            steps {
                script {
                    catchError(buildResult: 'UNSTABLE', stageResult: 'FAILURE' ) {
                        def image = docker.image("python:not_existing_tag")
                        image.pull()
                    }
                }
            }
        }
    }
}