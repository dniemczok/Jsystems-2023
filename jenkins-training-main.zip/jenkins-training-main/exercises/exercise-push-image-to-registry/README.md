### Description ###
Projekt ten będzie uruchamiał różne wersje aplikacji na różnych środowiskach ( windows, linux)

* Pamietaj aby tworzyc pipeline'y w wlasnym folderze, a projekty we własnym repozytorium Github

1. Wybierz opcje a lub b
  a. Stwórz Dockerfile, który uzyjesz do zbudowania obrazu
  b. Sciagnij obraz dockerowy

2. Uzyj dockerfile (opcja a) do zbudowania obrazu lub przetaguj sciagniety obraz (opcja b)

3. Wykonaj push image'u do swojego registry na github

[Useful links](../README.md)
