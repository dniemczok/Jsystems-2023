### Description ###
Pipeline wprowadzajacy z uzyciem osobnych agentow dla roznych stage'y


* Pamietaj aby tworzyc pipeline'y w wlasnym folderze, a projekty we własnym repozytorium Github

1. Stworz projekt typu pipeline

2. Nie alokuj agenta dla całego pipelien'u tylko dla poszczególnych stage'y

3. Stworz pipeline, ktory zawiera dwa stage:
   - stage 1 o nazwie "Check maven version"
   - stage 2 o nazwie "Check java version"

4. Dla stage 1 uzyj agent'a z docker image "maven:3-alpine". Sprawdz jaka dokladnie wersje maven'a ma dany docker image za pomocą odpowiedniej komendy.

5. Dla stage 2 uzyj agent'a z image "openjdk:8-jre". Sprawdz jaka dokladnie wersje javy ma dany docker image


[Useful links](../README.md)