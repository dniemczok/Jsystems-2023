Useful links:

```
Directive Generator (Pipeline syntax generator)
https://jenkins.mgworkshop.eu/directive-generator/

Snippet generator (Steps)
https://jenkins.mgworkshop.eu/pipeline-syntax/

Global variables
https://jenkins.mgworkshop.eu/pipeline-syntax/globals

Jenkins documentation syntax
https://www.jenkins.io/doc/book/pipeline/syntax/

Jenkins docuemntation steps
https://www.jenkins.io/doc/pipeline/steps/

```