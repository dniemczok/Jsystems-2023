### Description ###

Zadanie będzie polegało na utowrzeniu dwóch pipeline'ow. Pipeline pierwszy będzie triggerował pipeline drugi


* Pamietaj aby tworzyc pipeline'y w wlasnym folderze, a projekty we własnym repozytorium Github

Umiesc pipeline'y w swoim projekcie Github i załaduj je za pomocą metody "Load pipeline script from SCM".
Pamiętaj o dodaniu odpowiedniego tokenu do Jenkinsa.

1. Utwórz pipeline z użyciem sekcji "post", która wykona się tylko w przypadku zakończenia stage'u niepowodzeniem. Wymuś uruchomienie sekcji post poprzez odpowiednie zakończenie stage'a (exit 1 dla stage).
2. W sekcji post wymuś uruchomienie innego pipeline'u oraz przekaż przykładową wybraną przez Ciebie zmienną.
3. Utwórz piepline downstream, w którym wykonasz dowolny krok z użyciem zmiennej z pipeline'u upstream.


[Useful links](../README.md)
