### Description ###
Projekt ten będzie uruchamiał różne wersje aplikacji na różnych środowiskach ( windows, linux)

* Pamietaj aby tworzyc pipeline'y w wlasnym folderze, a projekty we własnym repozytorium Github

1. Stworz projekt typu Matrix (Multi-configuration project). 

2. Utwórz macierz 4x2 
   Na jednej osi umieść wersje aplikacji (1.0.0 1.0.0-SNAPSHOT 2.0.0 2.0.0-SNAPSHOT) - 4 wiersze . Na drugiej z osi umieść środowiska ( test, production ) - 2 kolumny

3. Skonfiguruj projekt tak, aby mozliwe było tylko uzycie wersji releasowej ( 1.0.0, 2.0.0 ) tylko na środowisku production oraz wersji SNAPSHOT tylko na środowisku test ( Użycie combination filter)

4. Dodaj odpowiedni step w sekcji Build, który wyświetli wersje aplikacji oraz środowisko.

5. Przetesuj swój job

[Useful links](../README.md)
