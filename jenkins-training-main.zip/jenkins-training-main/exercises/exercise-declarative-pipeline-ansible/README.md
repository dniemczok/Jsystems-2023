### Description ###
Celem tego cwiczenia jest utworzenie własnego projektu z playbookiem Ansible i wywolanie za pomoca Jenkins Pipeline

* Pamietaj aby tworzyc pipeline'y w wlasnym folderze, a projekty we własnym repozytorium Github

1. Stwórz własne repozytorium w GH z Ansible Playbook oraz inventory. Mozesz wykorzystac https://github.com/devopsit-mg/ansible jako szablon.
2. Stwórz odpowiednio task:
    * Ktory skopiuje zawartość projektu z plikami Ansible do katalogu /opt/imie_nazwisko
    * Wyswietli zawartość katalogu
    
3. Utworz pipeline z dwoma stage'ami:

4. W pierwszym stage'u wykonaj Checkout swojego projektu (uzyj credentiali dla Twojego konta GH)

5. W drugim stage'u uruchom Twój playbook

6. Czy widzisz "output" z zawartościa katalogu w konsoli jenkinsa ?

[Useful links](../README.md)