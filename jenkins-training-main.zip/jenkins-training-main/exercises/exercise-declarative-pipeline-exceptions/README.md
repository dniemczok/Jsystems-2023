### Description ###
Wyjątki w pipeline'ach

* Pamietaj aby tworzyc pipeline'y w wlasnym folderze, a projekty we własnym repozytorium Github

Celem tego cwiczenia bedzie stworzenie dwoch roznych pipeline'ow oraz wyłapaniem wyjatku z uzyciem wbudowanej funkcji pipeline'u (catchError) oraz uzyciem bloku try/catch.

Uzyj jako agent'a slave'a o nazwie "slave01"

1. Utworz pipeline "exception-1-try"

2. Utworz dwa stage. 

3. W pierwszym stage'u ("Pull image 1") sprobuj pobrac obraz dockerowy z publicznego repozytorium, ktory istnieje - ten stage powinien zakończyć się sukcesem.

4. W drugim stage'u  ("Pull image 2") pobierz obraz dockerowy, który nie istnieje. Uzyj bloku try/catch aby wyłapać wyjątek. Wyswietl wyjatek oraz ustaw status build'a jako "UNSTABLE"


5. Utworz pipeline "exception-2-catchErr"

6. Wykonaj takie same kroki jak w pipeline "exception-1-try", z uzyciem wbudowanej funkcji (catchError). Zmień status stage ("Pull image 2") na 'FAILURE' a status build'u na "UNSTABLE"

[Useful links](../README.md)
