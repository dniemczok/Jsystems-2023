### Description ###
Warunki wbudowane oraz warunki z uzyciem dyrektywy "script"

* Pamietaj aby tworzyc pipeline'y w wlasnym folderze, a projekty we własnym repozytorium Github

Umiesc pipeline'y w swoim projekcie Github i załaduj je za pomocą metody "Load pipeline script from SCM".
Pamiętaj o dodaniu odpowiedniego tokenu do Jenkinsa.

1. Stworz projekt typue pipeline

2. Pipeline będzie zawierał parametr pozwalajacy na wybranie odpowiedniego środowiska sposrod dev,stage, demo, prod

3. Utwórz dwa stage:
- stage 1, z użyciem warunku "when", który wykona deployment jeśli zostało wybrane środowisko demo. Wyswietl na konsole dodatkowo "Deployment on $env" - gdzie $env to typ srodowiska, na ktore wykonywany jest deployment.
- stage 2, utwórz warunek bez użycia "when" wewnątrz stage'u. Użyj sekcji "script" i napisz tam warunek. Wyswietl na konsole dodatkowo "Deployment on $env" - gdzie $env to typ srodowiska, na ktore wykonywany jest deployment.

4. Użyj dowolnego agenta

[Useful links](../README.md)
