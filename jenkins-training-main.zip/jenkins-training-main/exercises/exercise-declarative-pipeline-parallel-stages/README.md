### Description ###

* Pamietaj aby tworzyc pipeline'y w wlasnym folderze, a projekty we własnym repozytorium Github

1. Stworz pipeline składający się z 5 stage'y ( w tym 3 równoległe) - Zobacz rysunek. 

2. "STAGE-A" powinien zawierać step "input", który wyświetli prompt dla uzytkownika o treści "Continue?". 
Napisz pipeline tak, aby nie alokować agenta dla stage pierwszego, dopóki nie zostanie aktywowany przycisk. Input powinien byc mozliwy, do zaakceptowania tylko przez uzytkownika tworzacego pipeline (Twoj username).

3. W stage'u "STAGE-B" uzyj dyrektywy "parallel" aby uruchomić wewnątrz "STAGE-B" równolegle trzy stage (STAGE-C, STAGE-D,STAGE-E).
   "STAGE-D" powinień zakończyć się niepowodzeniem (mozesz uzyc funkcji exit)




Wizualizacja: 

![Pipeline view](pipeline-view.png?raw=true "Pipeline View")


[Useful links](../README.md)