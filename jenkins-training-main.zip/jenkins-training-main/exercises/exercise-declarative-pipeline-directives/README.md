### Description ###
Pipeline z uzyciem dyrektyw "options" oraz "environment"

* Pamietaj aby tworzyc pipeline'y w wlasnym folderze, a projekty we własnym repozytorium Github

1. Stworz projekt typu pipeline, który będzie ładowany z Twojego projektu na GitHub

2. Jako agent'a dla calego pipeline'u uzyj agenta "slave01"

3. Pipeline powinien zawierac nastepujace opcje (options directive):
- zachowanie historii 3 ostatnich buildow oraz artefaktow z 7 dni (buildDiscarder)
- timeout dla całego pipeline'u ustawiony na 5 minut (timeout)
- włączony timestamp (timestamps)

4. Pipeline z dwoma dowolnymi zmiennymi srodowiskowymi (environment directive)

5. Wewnatrz pipeline'u utworz dwa stage

6. W pierwszym stage'u wyswietl zmienne zdefiniowane w sekcji environment

7. W drugim stage'u nadpisz opcje timeout dla drugiego stage'a, ustaw ją na 30 sekund

8. Sprawdz czy timeout działa poprawnie. Mozesz uzyc komendy sleep.

9. Wyczysc workspace po zakoczeniu taskow.

[Useful links](../README.md)
