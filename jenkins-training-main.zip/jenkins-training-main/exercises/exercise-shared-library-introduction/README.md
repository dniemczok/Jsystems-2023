### Description ###

* Pamietaj aby tworzyc pipeline'y w wlasnym folderze, a projekty we własnym repozytorium Github

1. Utwórz własny projekt na Githubie, który będzie zawierał Twoją bibliotekę "Shared library"

2. Dodaj swoją bibliotekę w Jenkinsie - na poziomie folderu.

3. Utwórz plik w katalogu vars o nazwie 'scmUtils.groovy', który bedzie zawieral funkcje sluzace do zarzadznia Git'em

4. W pliku scmUtils.groovy utwórz funkcję gitCheckout, która pozwoli na checkout do wybranego brancha. Jako argument dla funkcji uzyj mapy.
   Uzyj 3 parametrow wewnatrz funkcji: 
   * Rewizja (branch)
   * url
   * credentials ID

5.  W pliku scmUtils.groovy utworz funkcje - setGitUserInfo, ktora ustawi odpowiednio username i email dla gita. Jako argument dla funkcji uzyj zmiennej typu mapa, lub dwóch stringów
   * Username
   * Email

HINT:  git config user.name / git config user.email

6. W pliku scmUtils.groovy utworz kolejna funkcje - gitCommit, ktora pozwoli na commit z odpowiednim komentarzem.  Jako argument dla funkcji uzyj mapy oraz 2       parametry:
   * Commit Message
   * Sciezke dla komendy "git add".

7. W pliku scmUtils.groovy utworz funkcje - gitPush, ktora pozwoli na push commit'u. Funkcja przyjmie argument pozwalający na przekazanie następujących parametrów:
 * credentialsId
 * gitHubPath ( sciezka do projektu na github) 
zaleznie od implementacji mozna zmienic parametry

8. Stwórz pipeline, w który uzyjesz wszystkich funkcji, które stworzyłeś w poprzednich krokach.

[Useful links](../README.md)
