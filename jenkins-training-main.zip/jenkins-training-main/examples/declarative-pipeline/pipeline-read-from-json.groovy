pipeline {
    agent any

    environment {
      gitUrl = "https://github.com/devopsit-mg/custom-project-stuff.git"
      githubCredentials = "github-access-mgworkshop"
    }

    stages {
        stage('Checkout') {
            steps {
                checkout([$class: 'GitSCM', branches: [[name: '*/main']], doGenerateSubmoduleConfigurations: false, extensions: [], submoduleCfg: [], userRemoteConfigs: [[credentialsId: githubCredentials, url: gitUrl]]])
            }
        }

        stage("Read json") {
            steps {
                script {
                    def props = readJSON file: 'example.json'
                    println props
                    println props['quiz']['sport']['q1']['options']
                }
            }
        }
    }
}