pipeline {
    agent none
    
    options {
        timestamps()
    }
    
    environment {
        githubCredentialsID = "github-access-mgworkshop"
        python_app_git_repo = "https://github.com/devopsit-mg/python-app-k8s.git"
        CONTAINER_REGISTRY = "ghcr.io"
        IMAGE_WORKSPACE = "devopsit-mg"
        IMAGE_NAME = "python-app"
        IMAGE_VERSION = 1.0
        IMAGE_PATH = "$CONTAINER_REGISTRY/$IMAGE_WORKSPACE/$IMAGE_NAME:$IMAGE_VERSION"
        // Helm variables
        HELM_RELEASE_NAME = "python-app"
        // Gke Variables
        GCP_PROJECT_ID = "admin-project-273017"
        GKE_CLUSTER_NAME = "mgworkshop"
        GKE_REGION = "europe-west4"

    }
    
    parameters {
        string(name: 'branch', defaultValue: 'main', description: 'branch to checkout')
    }

    stages {
        stage("Checkout") {
            agent {
              docker { 
                image 'alpine:3.6' 
                label 'slave01' 
                reuseNode true }
            }
            steps {
              git url: env.python_app_git_repo, branch: params.branch, changelog: true, credentialsId: env.githubCredentialsID, poll: true
            }

        }

        stage("Run tests") {
            agent {
              docker { 
                image 'python:3.9-alpine'
                label 'slave01'
                reuseNode true }
            }
            steps {
              withEnv(["HOME=${env.WORKSPACE}"]) {
                sh '''
                      python -m venv .venv
                      source .venv/bin/activate
                      pip install -r app/requirements.txt
                      python -m pytest --junitxml=report.xml
                   '''
              }
            }
            post {
                    always {
                        junit 'report.xml'
                    }
                }
        }

        stage("Build image") {
            agent { label 'slave01' }
            steps {
              withCredentials([usernamePassword(credentialsId: env.githubCredentialsID, usernameVariable: 'username', passwordVariable: 'password')])
              {
                  sh "docker login -u $username -p $password $CONTAINER_REGISTRY"
              }
              sh "docker build . -t $IMAGE_PATH"
              sh "docker push $IMAGE_PATH"
            }

        }
        
        stage("Gcloud login") {
          agent { label 'slave01' }
          steps {
              withCredentials([file(credentialsId: 'gcp-service-account', variable: 'SA_CREDS')]) {
                sh "gcloud  auth activate-service-account --key-file=${SA_CREDS}"
                sh "gcloud config set project ${GCP_PROJECT_ID}"
              }
          }
        }

        stage("Deploy app to gke") {
          agent { label 'slave01' }
          steps {
            // Get GKE credentials
            sh "gcloud container clusters get-credentials ${GKE_CLUSTER_NAME} --region ${GKE_REGION}"
            // Deploy app to GKE cluster
            sh "helm upgrade --install --create-namespace --namespace mgworkshop ${HELM_RELEASE_NAME} deployment/"
          }

        }


    }
}
