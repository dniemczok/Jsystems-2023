#!/usr/bin/env groovy

@Library('devops-libs@one-node-k8s')_

import com.company.ManageVm
import com.company.Common
import com.helm.DeployDev
import com.helm.HelperDev
def vm = new ManageVm(this)
def common = new Common(this)
def helm = new DeployDev(this)
def helper = new HelperDev(this)

/// Project variables
def gkeProject = 'my-project'
def vmZone = 'europe-west4-c'
/// DNS variables
def dnsZoneName = 'my-zone-local'
def dnsSubdomain = 'my-zone.local'
/// VM Variables
def coreNumber = '12'
def memory = "26GB"
def image = "microk8s"
// Id of credentials in Jenkins for connecting to VMs
//sshPrivKeyId = 'one-node-k8s-ssh'
sshPrivKeyId = 'scmKey'
sshUsername = 'scmuser'
// Variables for gitlab repository to download basic configuration for dev-docker
def repoUrl = "repo-url"
def credentialsId = "557152d9-0ce5-478e-b169-985219469acc"
// Variables for gitlab registry to download image
def registryUrl = "https://registry.gitlab.com"
// Credentials are read only token on multi-deploy repo
def registryCredentialsId = "gitlab-registry-multideploy"
// Setup K8s config variables
def envType = 'dev'
def envConfig = 'dev-docker'

properties([
        parameters(
                [    string(defaultValue: '', description: 'Name of the environment to create with create action type. Only hyphens (-), underscores (_), lowercase characters, and numbers are allowed', name: 'ENVIRONMENT', trim: false),
                     string(defaultValue: 'master', description: 'Branch name of the repository where basic configuration for environment is set up', name: 'branchName', trim: false),
                     choice(name: 'ACTION_TYPE', choices: ['create','update'], description: 'When create is chosen new environment will be created using ENVIRONMENT parameter and if the given name exists pipeline will be interrupted. If you would like to update your existing environment choose update option and choose your env using "env" parameter. If there is no your environment on list firstly start it.'),
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: '', filterable: false, name: 'TEAM', randomName: 'choice-parameter-3119488730410222', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'get_department.groovy']],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: 'This list appears when update option is chosen and there env that can be updated',  filterable: false, name: 'env', randomName: 'choice-parameter-3119488730410123', referencedParameters: 'ACTION_TYPE,TEAM',
                      script: [$class: 'GroovyScript', fallbackScript: [classpath: [], sandbox: false, script: ''], script: [classpath: [], sandbox: false, script: """ 
                                def choices
                                
                                switch(ACTION_TYPE){
                                    case ~/(update)/:
                                        get = "/var/lib/jenkins/gcloud/get_all_env.sh \$TEAM dev-global-295114".execute()
                                        get.waitFor()
                                        choices = get.text.tokenize('\\n')
                                        break
                                    default:
                                        choices = ['N/A']
                                        break
                                }
                                return choices
                                """.stripIndent()]]],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_MULTI_SELECT', description: '',  filterable: false, name: 'active_envs', randomName: 'choice-parameter-3119488730410223', referencedParameters: 'TEAM',
                      script: [$class: 'GroovyScript', fallbackScript: [classpath: [], sandbox: false, script: ''], script: [classpath: [], sandbox: false, script: """ 
                                get = "/var/lib/jenkins/gcloud/get_all_env_with_name.sh \$TEAM dev-global-295114".execute()
                                get.waitFor()
                                choices = get.text.tokenize('\\n')
                                """.stripIndent()]]],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_CHECKBOX', description: '', filterLength: 5, filterable: false, defaultValue: ['api','app','report','scheduler','shared','jackpot','configuration','currency','user','boostgame','boostbucket','boostmanager'] ,name: 'SERVICES_TO_DEPLOY', randomName: 'choice-parameter-3119488730410111', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'get_deployment_services_list.groovy']],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: '', filterLength: 5, filterable: true, name: 'BACKEND_VERSION', randomName: 'choice-parameter-3119488730410204', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'get_backend_images_no_latest.groovy']],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: '', filterLength: 5, filterable: true, name: 'JACKPOT_VERSION', randomName: 'choice-parameter-3119488730410285', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'get_jackpot_tags.groovy']],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: '', filterLength: 5, filterable: true, name: 'CONFIGURATION_VERSION', randomName: 'choice-parameter-3119488730410206', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'get_configuration_tags.groovy']],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: '', filterLength: 5, filterable: true, name: 'CURRENCY_VERSION', randomName: 'choice-parameter-3119488730410207', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'get_currency_tags.groovy']],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: '', filterLength: 5, filterable: true, name: 'GAMBLING_VERSION', randomName: 'choice-parameter-3119488730410208', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'get_gambling_tags.groovy']],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: '', filterLength: 5, filterable: true, name: 'USER_VERSION', randomName: 'choice-parameter-3119488730410209', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'get_user_tags.groovy']],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: '', filterLength: 5, filterable: true, name: 'GATEWAY_VERSION', randomName: 'choice-parameter-3119488730410210', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'get_gateway_tags.groovy']],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: '', filterLength: 5, filterable: true, name: 'EXTERNAL_VERSION', randomName: 'choice-parameter-3119488730410211', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'get_eventhub_tags.groovy']],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: '', filterLength: 5, filterable: true, name: 'WAGERLISTENER_VERSION', randomName: 'choice-parameter-3119488730410212', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'get_wager_tags.groovy']],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: '', filterLength: 5, filterable: true, name: 'VEIKKAUSLISTENER_VERSION', randomName: 'choice-parameter-3119488730410213', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'get_veikkaus_tags.groovy']],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: '', filterLength: 5, filterable: true, name: 'BOOSTMANAGER_VERSION', randomName: 'choice-parameter-3119488730410214', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'get_boostmanager_images.groovy']],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: '', filterLength: 5, filterable: true, name: 'BOOSTBUCKET_VERSION', randomName: 'choice-parameter-3119488730410215', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'get_boostbucket_images.groovy']],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: '', filterLength: 5, filterable: true, name: 'BOOSTGAME_VERSION', randomName: 'choice-parameter-3119488730410216', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'get_boostgame_images.groovy']],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: '', filterLength: 5, filterable: true, name: 'INTEGRATION_SCHEDULER_VERSION', randomName: 'choice-parameter-3119488730410217', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'integration_scheduler_image.groovy']],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: '', filterLength: 5, filterable: true, name: 'OPERATORFUNCTIONAL_MOCK_VERSION', randomName: 'choice-parameter-3119488730410218', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'get_operatorfunctionalmocks_tags.groovy']],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: '', filterLength: 5, filterable: true, name: 'GAMEINSTALLATION_VERSION', randomName: 'choice-parameter-3119488730410219', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'get_gameconfiguration_image.groovy']],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: '', filterLength: 5, filterable: true, name: 'DEBEZIUM_VERSION', randomName: 'choice-parameter-3119488730410280', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'get_debezium_tags.groovy']],
                     [$class: 'CascadeChoiceParameter', choiceType: 'PT_SINGLE_SELECT', description: '', filterLength: 5, filterable: true, name: 'CONFIGSERVER_VERSION', randomName: 'choice-parameter-3119488730410987', script: [$class: 'ScriptlerScript', parameters: [], scriptlerScriptId: 'get_configserver_tags.groovy']],
                     booleanParam(defaultValue: false, description: 'Option changes expiration day from default 7 days to 1 day', name: 'AUTOMATION_TESTS')

                ]
        )
]
)

def mapServiceToVersion = helper.mapServiceToVersion()
def actionType = params.ACTION_TYPE
def ENVIRONMENT


if (actionType == "create") {
    ENVIRONMENT = params.ENVIRONMENT.toLowerCase()
} else if (actionType == "update") {
    ENVIRONMENT = params.env
}

if (ENVIRONMENT == "" && actionType == "create") {
    println("Please setup ENVIRONMENT variable")
    currentBuild.result = 'UNSTABLE'
    return
}

if (params.env == "" && actionType == "update") {
    println("Please choose you environment with 'env' field")
    currentBuild.result = 'UNSTABLE'
    return
}

def passValidationEnvName = vm.validateEnvironmentName(ENVIRONMENT)

if (passValidationEnvName) {
    println("Validation name of Environment passed")
} else if (! passValidationEnvName) {
    println("Incorrect environment name. Only hyphens (-), underscores (_), lowercase characters, and numbers are allowed. International characters are allowed. Additionally env with word 'web', 'report', 'bo-' is not allowed")
    currentBuild.result = 'UNSTABLE'
    return
}

println(params.SERVICES_TO_DEPLOY)

node('slave01') {

    currentBuild.displayName = "${ENVIRONMENT}"

    wrap([$class: 'BuildUser']) {
        env.buildUserId= "${BUILD_USER_ID}"
        env.buildUserEmail= "${BUILD_USER_EMAIL}"
    }

    docker.withRegistry(registryUrl, registryCredentialsId) {
        docker.image('registry.gitlab.com/multideploy:latest').inside('-u root') {

        stage("gcloud login") {
                withCredentials([file(credentialsId: 'one-node-k8s-mgmt', variable: 'SA_CREDS')]) {
                    sh "gcloud  auth activate-service-account --key-file=${SA_CREDS}"
                    sh "gcloud config set project ${gkeProject}"

                }
            }


        stage('Create VM') {
            def vmExist = vm.checkIfVmAlreadyExist(ENVIRONMENT,vmZone)
            def vmStatus = vm.checkVmStatus(ENVIRONMENT, vmZone)
            // Stop if vm with given name exist and actionType create
            if ( vmExist && actionType == "create" ) {
                error("Given environment already exist. Please choose different name or change action type to update.")
                currentBuild.result = 'UNSTABLE'
            } else if ( ! vmExist && actionType == "create" ) {
                vm.createVm(ENVIRONMENT, vmZone, coreNumber, memory, image,'standard',params.TEAM,env.buildUserId,env.buildUserEmail,params.AUTOMATION_TESTS)
                sh 'sleep 35'
                // Get internal Ip of VM
                vmInternalIp = vm.getVmInternalIp(ENVIRONMENT, vmZone)
                sshagent([sshPrivKeyId]) {
                    if (actionType == "create") {
                        vm.setupMicrok8s(vmInternalIp,sshUsername)
                    }
                }
            } else if ( actionType == "update" && vmStatus == "TERMINATED" ) {
                vmInternalIp = vm.getVmInternalIp(ENVIRONMENT, vmZone)
                vm.startVm(ENVIRONMENT,vmZone)
                sh "sleep 30"
                sshagent([sshPrivKeyId]) {
                    vm.startMicrok8s(vmInternalIp,sshUsername)
                    sh "sleep 10"
                }
            } else if ( actionType == "update" && vmStatus == "RUNNING") {
                vmInternalIp = vm.getVmInternalIp(ENVIRONMENT, vmZone)
                println("Installing applications...")
            }
        }

        stage('Add DNS Record') {
            def dnsEntryExist = vm.checkIfDnsAlreadyExist(ENVIRONMENT,dnsZoneName,dnsSubdomain)

            if ( ! dnsEntryExist ) {
                vm.addDnsRecord(dnsZoneName, dnsSubdomain, ENVIRONMENT, vmInternalIp)
                vm.addDnsRecord(dnsZoneName, dnsSubdomain, "bo-${ENVIRONMENT}", vmInternalIp)
            } else {
                println("DNS Already Exist")
            }

        }

        stage("Get service account") {
            withCredentials([file(credentialsId: "one-node-k8s-mgmt", variable: "SA_CREDS")]) {
                sh(script: "#!/bin/bash +x \n" + ''' cat "${SA_CREDS}" > /opt/sa.json''', returnStdout: false)
            }
        }

        stage("Pull config repo") {
            common.pullGitRepo(repoUrl, params.branchName, credentialsId)
        }

        stage("Setup Kubeconfig/Tools") { 
            sshagent([sshPrivKeyId]) {
                kubeconfig = vm.setupKubectlContext(ENVIRONMENT, vmInternalIp,sshUsername)
            }

            helm.secretsRegistryApply(envType,envConfig)
            helm.installCoreDns(envType,envConfig)
            helm.installFluentd(envType,envConfig)
            vm.addLabelNode(ENVIRONMENT)
        }

        stage("Deploy Consul") {
            helm.addConsulRepo()
            helm.manageHelm(envType, envConfig,ENVIRONMENT,"hashicorp","consul", "--set ui.ingress.hosts[0].host=${ENVIRONMENT}.${dnsSubdomain} --set global.name=consul")
            helm.checkPvcBound('data-default-consul-server-0')
        }

        stage("Deploy Consul-kv") {
            def helmRepo = 'my-repo'
            def service = 'consul-kv'
            // Install Consul-kv
            withCredentials([usernamePassword(credentialsId: 'harbor-user', passwordVariable: 'HARBOR_USER_PASS', usernameVariable: 'HARBOR_USER')]) {
                helm.addRepo("${HARBOR_USER}", "${HARBOR_USER_PASS}", "${helmRepo}")
            }
            helm.manageHelm(envType, envConfig, ENVIRONMENT, helmRepo, service,"--set consulKv.envSpecificKeys=test.lan")
            helm.waitForUpdateWithLogs(service)
            helm.deleteJob(service)
        }


        stage("Deploy services no1") {

            def helmRepo = 'my-no1'

            // Install no1 services
            withCredentials([usernamePassword(credentialsId: 'harbor-user', passwordVariable: 'HARBOR_USER_PASS', usernameVariable: 'HARBOR_USER')]) {
                helm.addRepo("${HARBOR_USER}", "${HARBOR_USER_PASS}", "${helmRepo}")
            }

            for (service in no1ServicesListf) {
                imagePath = helper.getImagePathService(service)

                if (service == "database") {
                    def backendServicesToDeploy = helper.servicesToDeploy(params.SERVICES_TO_DEPLOY,backendServicesList)
                    databaseUpdate = helm.deployLiquibaseChecker(backendServicesToDeploy,backendServicesList)
                    if (databaseUpdate) {
                        if ( actionType == "update") {
                            helm.cleanDb()
                        }
                        helm.manageHelm(envType, envConfig, ENVIRONMENT, helmRepo, service, "--set ${imagePath}=${mapServiceToVersion[service]}")
                        helm.checkRolloutStatus('statefulset', service)
                        helm.checkPvcBound('database-database-0')
                        sh "sleep 40"
                    }
                } else {
                    helm.manageHelm(envType, envConfig, ENVIRONMENT, helmRepo, service)
                    helm.checkRolloutStatus('deployment', service)
                }
            }
        }

        stage("Deploy no2 services") {
            def helmRepo = 'my-no2'
            def boostServicesToDeploy = helper.servicesToDeploy(params.SERVICES_TO_DEPLOY,boostServicesList)
            withCredentials([usernamePassword(credentialsId: 'harbor-user', passwordVariable: 'HARBOR_USER_PASS', usernameVariable: 'HARBOR_USER')]) {
                helm.addRepo("${HARBOR_USER}", "${HARBOR_USER_PASS}", "${helmRepo}")
            }

            for (service in boostServicesToDeploy) {
                imagePath = helper.getImagePathService(service)

                if (service == "myservice") {
                    helm.manageHelm(envType, envConfig, ENVIRONMENT, helmRepo, service,"--set ${imagePath}=${mapServiceToVersion[service]}")
                    helm.waitForUpdateWithoutLogs(service)
                    // Delete job
                    helm.deleteJob(service)
                } else {
                    helm.manageHelm(envType, envConfig, ENVIRONMENT, helmRepo, service,"--set ${imagePath}=${mapServiceToVersion[service]}")
                    helm.checkRolloutStatus('deployment', service)
                }
            }

            helm.checkRolloutStatusServices('deployment',testServiceToDeploy,'testServiceToDeploy')

        }

        stage("Deploy no3 services") {
            def helmRepo = 'helm-no3'
            def coreServicesToDeploy = helper.servicesToDeploy(params.SERVICES_TO_DEPLOY,coreServicesList)
  
            withCredentials([usernamePassword(credentialsId: 'harbor-user', passwordVariable: 'HARBOR_USER_PASS', usernameVariable: 'HARBOR_USER')]) {
                helm.addRepo("${HARBOR_USER}", "${HARBOR_USER_PASS}", "${helmRepo}")
            }


            for (service in no3Services) {

                if (service in servicesWithDatabase) {
                    imagePathDatabase = helper.getImagePathServiceDatabase(service)
                    // Delete kv/artifactVersions
                    helm.deleteArtVersion(service)
                    //Delete deployment
                    helm.deleteDeployment(service)
                    // Update databse
                    helm.manageHelm(envType, envConfig, ENVIRONMENT, helmRepo, service + "-database", "--set ${imagePathDatabase}=${mapServiceToVersion[service]}")
                    // Waiting for liqubase
                    helm.waitForUpdateWithLogs(service + "-database")
                    // Delete job
                    helm.deleteJob(service + "-database")
                }

                imagePath = helper.getImagePathService(service)
                helm.manageHelm(envType, envConfig, ENVIRONMENT, helmRepo, service,"--set ${imagePath}=${mapServiceToVersion[service]}")
            }

            helm.checkRolloutStatusServices('deployment',coreServicesToDeploy)


        }

        stage('Check environment status') {

            def vmStatusPassed = vm.checkFnGamesStatus(ENVIRONMENT, 120)

            if ( vmStatusPassed ) {
                println("Health check for environment passed")
            } else {
                currentBuild.result = 'UNSTABLE'
                println("Health check for environment not passed")

            }
        }

        stage("Summary") {
            sh """  set +x echo \"
                #Backend
                https://${ENVIRONMENT}.local.lan
                #Backoffice
                https://fn-${ENVIRONMENT}.local.lan
                #Consul
                https://${ENVIRONMENT}.local.lan/ui
                \"
            """
        }
        }
    }
}








