pipeline {
    agent none
    stages {
        stage("Example build") {
            agent {
                docker {
                    image 'maven:3-alpine'
                }
            }
            steps {
                echo 'Hello, Maven'
                sh 'mvn --version'
            }
        }
        stage('Example test') {
            agent {
                docker {
                    image 'openjdk:8-jre'
                }
            }
            steps {
                echo 'Hello, JDK'
                sh 'java -version'
            }
        }
    }
}
