pipeline {
    agent any
    options {
        timeout(time: 1, unit: 'HOURS')
        disableConcurrentBuilds()
        buildDiscarder(logRotator(numToKeepStr: '3'))
        timestamps()
    }
    stages {
        stage("Example")) {
            steps {
                echo "Hello world"
                sh "sleep 10"
            }
        }
    }
}
