pipeline {
    agent any
    stages {
        stage("Test global vars") {
            steps {
                echo "My build ID: ${env.BUILD_ID}. My build display name: ${env.BUILD_DISPLAY_NAME}"
            }
        }
        stage("Override global vars") {
            steps {
                script {
                    currentBuild.displayName = "Run: ${currentBuild.number}. Image: ImageId"
                }
            }
        }
    }
}