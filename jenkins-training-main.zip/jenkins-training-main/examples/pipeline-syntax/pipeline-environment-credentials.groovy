pipeline {
    agent any
    stages {
        stage("Test env credentials") {
            environment {
                GITHUB_REGISTRY_CREDS = credentials('github-access-mgworkshop')
            }
            steps {
                sh "docker login -u ${GITHUB_REGISTRY_CREDS_USR} -p ${GITHUB_REGISTRY_CREDS_PSW} ghcr.io"
            }
        }
    }
}