pipeline {
    agent any
        stages {
            stage('Parameters'){
                steps {
                    script {
                    properties([
                            parameters([
                                [$class: 'ChoiceParameter', 
                                    choiceType: 'PT_SINGLE_SELECT', 
                                    description: 'City list', 
                                    filterLength: 1, 
                                    filterable: false, 
                                    name: 'City', 
                                    script: [
                                        $class: 'GroovyScript', 
                                        fallbackScript: [
                                            classpath: [], 
                                            sandbox: false, 
                                            script: 
                                                "return['Error']"
                                        ], 
                                        script: [
                                            classpath: [], 
                                            sandbox: false, 
                                            script: 
                                                "return[\"Krakow\",\"Wroclaw\",\"Warszawa\"]"
                                        ]
                                    ]
                                ],
                                [$class: 'CascadeChoiceParameter', 
                                    choiceType: 'PT_SINGLE_SELECT', 
                                    description: 'State list',
                                    name: 'States', 
                                    referencedParameters: 'City', 
                                    script: 
                                        [$class: 'GroovyScript', 
                                        fallbackScript: [
                                                classpath: [], 
                                                sandbox: false, 
                                                script: "return['Error']"
                                                ], 
                                        script: [
                                                classpath: [], 
                                                sandbox: false, 
                                                script: '''if ( City.equals("Krakow")) {
                                                                return ["Malopolska"]
                                                            } 
                                                            else if ( City.equals("Warszawa")) {
                                                                return ["Mazowieckie"]
                                                            } 
                                                            else if ( City.equals("Wroclaw")) {
                                                                return ["Dolnoslaskie"] }
                                                '''
                                            ] 
                                    ]
                                ],
                            ])
                        ])
                    }
                }
            }
        }   
}